from app.search import search


def main():

    print("=" * 70)
    print("Nexacro 17 Search Test")
    print("=" * 70)

    question = input("\n질문을 입력하세요: ")

    results = search(
        question,
        top_k=5
    )

    print("\n" + "=" * 70)
    print("검색 결과")
    print("=" * 70)

    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0]

    for i, document in enumerate(documents):

        print(f"\n[{i + 1}]")

        if i < len(distances):
            print(f"거리: {distances[i]}")

        if i < len(metadatas):
            print(f"Metadata: {metadatas[i]}")

        print("-" * 70)
        print(document[:1000])


if __name__ == "__main__":
    main()