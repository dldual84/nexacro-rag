from app.rag import ask


def main():

    print("=" * 70)
    print("Nexacro 17 RAG Test")
    print("=" * 70)

    question = input("\n질문을 입력하세요: ")

    answer, contexts = ask(
        question,
        top_k=5
    )

    print("\n")
    print("=" * 70)
    print("답변")
    print("=" * 70)

    print(answer)

    print("\n")
    print("=" * 70)
    print("참고 문서")
    print("=" * 70)

    for i, context in enumerate(contexts):

        metadata = context["metadata"]

        print(
            f"{i + 1}. "
            f"{metadata.get('title', '')} "
            f"(Section {metadata.get('section', '')}, "
            f"Page {metadata.get('page', '')})"
        )


if __name__ == "__main__":
    main()