from app.vector_store import VectorStore


def search(query, top_k=5):

    store = VectorStore()

    results = store.search(
        query=query,
        top_k=top_k
    )

    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0]

    contexts = []

    for i, document in enumerate(documents):

        metadata = metadatas[i] if i < len(metadatas) else {}
        distance = distances[i] if i < len(distances) else None

        contexts.append({
            "text": document,
            "metadata": metadata,
            "distance": distance
        })

    return contexts