from app.search import search
from app.llm import generate_answer


def ask(question, top_k=5):

    # 1. 관련 문서 검색
    contexts = search(
        query=question,
        top_k=top_k
    )

    # 2. 검색 결과를 LLM Context로 구성
    context_text = ""

    for i, item in enumerate(contexts):

        metadata = item["metadata"]

        section = metadata.get("section", "")
        title = metadata.get("title", "")
        page = metadata.get("page", "")

        context_text += f"""
[문서 {i + 1}]
Section: {section}
Title: {title}
Page: {page}

{item["text"]}

"""

    # 3. LLM에게 질문 + Context 전달
    answer = generate_answer(
        question,
        context_text
    )

    return answer, contexts